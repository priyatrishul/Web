package edu.sdsu.cs645.server;

import edu.sdsu.cs645.client.NotepadService;
import edu.sdsu.cs645.shared.FieldVerifier;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import java.io.*;
import java.util.*;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class NotepadServiceImpl extends RemoteServiceServlet implements
    NotepadService {

  public String load() throws IllegalArgumentException {
    String path=getServletContext().getRealPath("/");
    String fileName=path+"/data.txt";
    String answer="";
    String line;
    try{
    	BufferedReader in=new BufferedReader(
    		new FileReader(fileName));
    	while((line = in.readLine())!=null)
    		answer+=line;
    		in.close();   	
    }catch(Exception e){
    	return "Failed to read File";
    }
    return answer;
    }
    public String save(String contents) throws IllegalArgumentException {
    String path=getServletContext().getRealPath("/");
    String fileName=path+"/data.txt";
    String answer="";
    String line;
    try{
    	PrintWriter out=new PrintWriter(
    		new FileWriter(fileName));
    		contents=contents.replace("\r\n|\n","<br/>");
    		out.print(contents);
    		out.close();
    }
    catch(Exception e){
    	return "Error,Failed to save file";
    }
    	return "OK,Success,File saved";
    
    }
    public String validateLogin(String s) throws IllegalArgumentException {
    if(s.trim().equals("sp2015")) return "OK";
    return "INVALID";
    }
    public TreeMap loadMap() throws IllegalArgumentException {
      TreeMap<String,String> t=  new TreeMap<String,String>();
      t.put("1_one","uno");
      t.put("2_two","dos");
      t.put("3_three","tres");
      t.put("4_four","quatro");
    
    return t;
    }
}
    

