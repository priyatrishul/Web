package edu.sdsu.cs645.client;

import edu.sdsu.cs645.shared.FieldVerifier;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.*;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.*;
import java.util.*;


public class Notepad implements EntryPoint {
  
  private static final String SERVER_ERROR = "An error occurred while "
      + "attempting to contact the server. Please check your network "
      + "connection and try again.";

  
  private final NotepadServiceAsync notepadService = GWT.create(NotepadService.class);
  private RichTextArea pad;
  private HTML status;

  public void onModuleLoad() {
    status = new HTML();
    status.setStyleName("status_panel");
    //buildMainPanel();
    buildLogin();
    
  }
  private void buildLogin(){

    FlowPanel loginPanel =new FlowPanel();
    loginPanel.getElement().setId("log_panel");
    loginPanel.add(new HTML("<h1>Please Enter your Password</h1>"));
    FlowPanel loginPanel1 =new FlowPanel();
    final PasswordTextBox password=new PasswordTextBox();
    loginPanel1.setStyleName("log_panel1");
    loginPanel1.add(new Label("Password"));
    loginPanel1.add(password);
    FlowPanel bPanel=new FlowPanel();
    bPanel.setStyleName("blog_panel");
    Button loginButton = new Button("Login");
    Button clearButton = new Button("Clear");
    loginButton.setStyleName("log_button");
    clearButton.setStyleName("log_button");
    clearButton.addClickHandler(new ClickHandler(){

      public void onClick(ClickEvent e){
        password.setText("");
        status.setText("");
      }

    });
     loginButton.addClickHandler(new ClickHandler(){

      public void onClick(ClickEvent e){
        validateLogin(password.getText());
      }

    });
     
     bPanel.add(loginButton);
     bPanel.add(clearButton);
     bPanel.add(status);
     loginPanel.add(loginPanel1);
     loginPanel.add(bPanel);
     RootPanel.get().add(loginPanel);
     password.setFocus(true);

  }
  private void buildMainPanel()
  {
      FlowPanel main= new FlowPanel();
      Button logoutButton = new Button("LogOut");
      logoutButton.setStyleName("logout_btn");
      logoutButton.addClickHandler(new ClickHandler(){
      public void onClick(ClickEvent e){
        status.setText("");
        RootPanel.get().clear();
        buildLogin();
      }

    });
      main.add(logoutButton);
      main.add(new HTML ("<h1>Online Notepad</h1>"));
      pad=new RichTextArea();
      main.add(getButtonPanel());
      main.add(pad);
      main.add(status);  
      RootPanel.get().clear();
      RootPanel.get().add(main);
      loadPanel();
  }

  private FlowPanel getButtonPanel()
  {
    FlowPanel p =new FlowPanel();
    Button clear =new Button("Clear");
    Button save =new Button("Save");
    Button load =new Button("Load");
    Button loadMap =new Button("LoadMap");
    clear.setStyleName("my_button");
    save.setStyleName("my_button");
    load.setStyleName("my_button");
    loadMap.setStyleName("my_button");
    clear.addClickHandler(new ClickHandler(){
      public void onClick(ClickEvent e){
        pad.setHTML("");
        status.setText("");
      }

    });
    save.addClickHandler(new ClickHandler(){
      public void onClick(ClickEvent e){
        savePanel();
      }

    });
    load.addClickHandler(new ClickHandler(){
      public void onClick(ClickEvent e){
        loadPanel();
      }

    });
    loadMap.addClickHandler(new ClickHandler(){
      public void onClick(ClickEvent e){
        loadMap();
      }

    });
    p.setStyleName("button_panel");  
    p.add(clear);   
    p.add(save);
    p.add(load);
    p.add(loadMap);
    return p;

  }

  private void savePanel(){
    AsyncCallback callBack= new AsyncCallback(){
      public void onSuccess(Object Results){
        status.setText((String)Results);

      }
      public void onFailure(Throwable err){}
    };
    notepadService.save(pad.getHTML(),callBack);

  }
  private void loadPanel(){
    AsyncCallback callBack= new AsyncCallback(){
      public void onSuccess(Object Results){
        pad.setHTML((String)Results);
        status.setText("File contents loaded successfully");

      }
      public void onFailure(Throwable err){}
    };
    notepadService.load(callBack);

  }
   private void loadMap(){
    AsyncCallback callBack= new AsyncCallback(){
      public void onSuccess(Object Results){
        TreeMap t1=(TreeMap) Results;
        String toDisplay="<table>";
        Iterator<String> k= t1.keySet().iterator();
        Iterator<String> v=t1.values().iterator();
        while(k.hasNext()){
          toDisplay+="<tr>";
          toDisplay+="<td>"+k.next()+"</td>";
          toDisplay+="<td>"+v.next()+"</td>";
          toDisplay+="</tr>";
        }
        toDisplay+="</table>";
        pad.setHTML(toDisplay);
        status.setText("Map loaded successfully");

      }
      public void onFailure(Throwable err){}
    };
    notepadService.loadMap(callBack);

  }
   private void validateLogin(String password){
    AsyncCallback callBack= new AsyncCallback(){
      public void onSuccess(Object Results){
        String answer=((String)Results);
        if(answer.equals("OK")){
          status.setText("");
        buildMainPanel();
      }
      else
        status.setText("Invalid Password");
      }
      public void onFailure(Throwable err){
        status.setText("Failed"+err.getMessage());
      }
    };
    notepadService.validateLogin(password,callBack);

  }
}
